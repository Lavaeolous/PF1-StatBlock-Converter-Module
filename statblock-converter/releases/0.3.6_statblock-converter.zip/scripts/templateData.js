export default {
    "name": "",
    "classes": {},
    "slug": "",
    "flavor_text": "",
    "cr": 0,
    "xp": 0,
    "size": "",
    "alignment": "",
    "gender": "",
    "race": "",
    "creature_type": "",
    "creature_subtype": "",
    "initiative": 0,
    "senses": "",
    "aura": "",
    "hp": {
        "total": 0,
        "racial": 0,
        "class": []
    },
    "hit_dice" : {
        "hd": {
            "total": 0,
            "racial": 0,
            "class": []
        },
        "hd_diceSize": {
            "racial": 0,
            "class": []
        },
        "hd_bonus": 0
    },
    "ac": 0,
    "touch": 0,
    "flat_footed" : 0,
    "ac_race_bonus": 0,
    "ac_bonus_types" : {},
    "cmd": {
        "total": 0,
        "context": ""
    },
    "cmb": {
        "total": 0,
        "context": ""
    },
    "fort_save": {
        "total": 0,
        "racial": 0,
        "class": []
    },
    "ref_save": {
        "total": 0,
        "racial": 0,
        "class": []
    },
    "will_save": {
        "total": 0,
        "racial": 0,
        "class": []
    },
    "save_notes": "",
    "defensive_abilities": "",
    "immunities": "",
    "resistances": "",
    "weaknesses": "",
    "spell_resistance": {
        "total": 0,
        "context": ""
    },
    "damage_reduction": {
        "dr_value" : 0,
        "dr_type" : ""
    },
    "regeneration": "",
    "fast_healing": "",
    "speed": {
        "land": {
          "base": 30,
          "total": 30
        },
        "climb": {
          "base": 0,
          "total": 0
        },
        "swim": {
          "base": 0,
          "total": 0
        },
        "burrow": {
          "base": 0,
          "total": 0
        },
        "fly": {
          "base": 0,
          "total": 0,
          "maneuverability": "average"
        }
    },
    "meleeAttacks": "",
    "rangedAttacks": "",
    "specialAttacks": "",
    "space": 0,
    "reach": 0,
    "offensive_abilities": "",
    "spell_like_abilities": "",
    "spellcasting": {},
    "special_qualities": [],
    "str": {
        "total": 0,
        "race": 0
    },
    "dex": {
        "total": 0,
        "race": 0
    },
    "con": {
        "total": 0,
        "race": 0
    },
    "int": {
        "total": 0,
        "race": 0
    },
    "wis": {
        "total": 0,
        "race": 0
    },
    "cha": {
        "total": 0,
        "race": 0
    },
    "feats": [],
    "skills": {
        "acrobatics" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "appraise" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "bluff" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "climb" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "craft" : {},
        "diplomacy" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "disable device" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "disguise" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "escape artist" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "fly" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "handle animal" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "heal" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "intimidate" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "knowledge" : {
            "arcana" : {
                "total": 0,
                "race": 0,
                "context": ""
            },
            "dungeoneering" : {
                "total": 0,
                "race": 0,
                "context": ""
            },
            "engineering" : {
                "total": 0,
                "race": 0,
                "context": ""
            },
            "geography" : {
                "total": 0,
                "race": 0,
                "context": ""
            },
            "history" : {
                "total": 0,
                "race": 0,
                "context": ""
            },
            "local" : {
                "total": 0,
                "race": 0,
                "context": ""
            },
            "nature" : {
                "total": 0,
                "race": 0,
                "context": ""
            },
            "nobility" : {
                "total": 0,
                "race": 0,
                "context": ""
            },
            "planes" : {
                "total": 0,
                "race": 0,
                "context": ""
            },
            "religion" : {
                "total": 0,
                "race": 0,
                "context": ""
            }
        },
        "linguistics" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "perception" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "perform" : {},
        "profession" : {},
        "ride" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "sense motive" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "sleight of hand" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "spellcraft" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "stealth" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "survival" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "swim" : {
            "total": 0,
            "race": 0,
            "context": ""
        },
        "use magic device" : {
            "total": 0,
            "race": 0,
            "context": ""
        }
    },
    "tactics": {
        "before_combat" : "",
        "during_combat" : "",
        "morale" : "",
        "base_statistics" : "",
        "default" : ""
    },
    "languages": "",
    "gear": "",
    "other_abilities": "",
    "environment": "",
    "organization": "",
    "special_abilities": {},
    "description": ""
};