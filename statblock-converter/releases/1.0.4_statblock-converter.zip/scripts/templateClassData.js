export default {
    "classOrRacialHD": {
        "level": 1,
        "name": "",
        "hd": 1,
        "bab": "",
        "hp": false,
        "savingThrows": {
          "fort": 0,
          "ref": 0,
          "will": 0
        },
        "fc": {
          "hp": 0,
          "skill": 0,
          "alt": 0
        }
      }
};