export default {
    "name": "",
    "classes": {},
    "slug": "",
    "flavor_text": "",
    "cr": 0,
    "xp": 0,
    "size": "",
    "alignment": "",
    "gender": "",
    "race": "",
    "creature_type": "",
    "creature_subtype": "",
    "initiative": 0,
    "senses": "",
    "aura": "",
    "hp": {
        "total": 0,
        "racial": 0,
        "class": []
    },
    "hit_dice" : {
        "hd": {
            "total": 0,
            "racial": 0,
            "class": []
        },
        "hd_diceSize": {
            "racial": 0,
            "class": []
        },
        "hd_bonus": 0
    },
    "ac": 0,
    "touch": 0,
    "flat_footed" : 0,
    "ac_race_bonus": 0,
    "ac_bonus_types" : {},
    "cmd": {
        "total": 0,
        "context": ""
    },
    "cmb": {
        "total": 0,
        "context": ""
    },
    "fort_save": {
        "total": 0,
        "racial": 0,
        "class": []
    },
    "ref_save": {
        "total": 0,
        "racial": 0,
        "class": []
    },
    "will_save": {
        "total": 0,
        "racial": 0,
        "class": []
    },
    "defensive_abilities": "",
    "immunities": "",
    "resistances": "",
    "weaknesses": "",
    "spell_resistance": {
        "total": 0,
        "context": ""
    },
    "damage_reduction": {
        "dr_value" : 0,
        "dr_type" : ""
    },
    "regeneration": "",
    "fast_healing": "",
    "speed": {
        "land": {
          "base": 30,
          "total": 30
        },
        "climb": {
          "base": 0,
          "total": 0
        },
        "swim": {
          "base": 0,
          "total": 0
        },
        "burrow": {
          "base": 0,
          "total": 0
        },
        "fly": {
          "base": 0,
          "total": 0,
          "maneuverability": "average"
        }
    },
    "meleeAttacks": "",
    "rangedAttacks": "",
    "specialAttacks": "",
    "space": 0,
    "reach": 0,
    "offensive_abilities": "",
    "spell_like_abilities": "",
    "spellcasting": {},
    "special_qualities": [],
    "str": {
        "total": 0,
        "race": 0
    },
    "dex": {
        "total": 0,
        "race": 0
    },
    "con": {
        "total": 0,
        "race": 0
    },
    "int": {
        "total": 0,
        "race": 0
    },
    "wis": {
        "total": 0,
        "race": 0
    },
    "cha": {
        "total": 0,
        "race": 0
    },
    "feats": [],
    "skills": {
        "acrobatics" : {
            "total": 0,
            "race": 0
        },
        "appraise" : {
            "total": 0,
            "race": 0
        },
        "bluff" : {
            "total": 0,
            "race": 0
        },
        "climb" : {
            "total": 0,
            "race": 0
        },
        "craft" : {},
        "diplomacy" : {
            "total": 0,
            "race": 0
        },
        "disable device" : {
            "total": 0,
            "race": 0
        },
        "disguise" : {
            "total": 0,
            "race": 0
        },
        "escape artist" : {
            "total": 0,
            "race": 0
        },
        "fly" : {
            "total": 0,
            "race": 0
        },
        "handle animal" : {
            "total": 0,
            "race": 0
        },
        "heal" : {
            "total": 0,
            "race": 0
        },
        "intimidate" : {
            "total": 0,
            "race": 0
        },
        "knowledge" : {
            "arcana" : {
                "total": 0,
                "race": 0
            },
            "dungeoneering" : {
                "total": 0,
                "race": 0
            },
            "engineering" : {
                "total": 0,
                "race": 0
            },
            "geography" : {
                "total": 0,
                "race": 0
            },
            "history" : {
                "total": 0,
                "race": 0
            },
            "local" : {
                "total": 0,
                "race": 0
            },
            "nature" : {
                "total": 0,
                "race": 0
            },
            "nobility" : {
                "total": 0,
                "race": 0
            },
            "planes" : {
                "total": 0,
                "race": 0
            },
            "religion" : {
                "total": 0,
                "race": 0
            }
        },
        "linguistics" : {
            "total": 0,
            "race": 0
        },
        "perception" : {
            "total": 0,
            "race": 0
        },
        "perform" : {},
        "profession" : {},
        "ride" : {
            "total": 0,
            "race": 0
        },
        "sense motive" : {
            "total": 0,
            "race": 0
        },
        "sleight of hand" : {
            "total": 0,
            "race": 0
        },
        "spellcraft" : {
            "total": 0,
            "race": 0
        },
        "stealth" : {
            "total": 0,
            "race": 0
        },
        "survival" : {
            "total": 0,
            "race": 0
        },
        "swim" : {
            "total": 0,
            "race": 0
        },
        "use magic device" : {
            "total": 0,
            "race": 0
        }
    },
    "tactics": {
        "before_combat" : "",
        "during_combat" : "",
        "morale" : "",
        "base_statistics" : "",
        "default" : ""
    },
    "languages": "",
    "gear": "",
    "other_abilities": "",
    "environment": "",
    "organization": "",
    "special_abilities": {},
    "description": ""
};