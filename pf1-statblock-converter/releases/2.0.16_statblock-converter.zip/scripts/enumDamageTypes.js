export default [
          "bludgeoning",
          "piercing",
          "slashing",
          "cold",
          "fire",
          "electricity",
          "electric",
          "sonic",
          "acid",
          "force",
          "negative",
          "positive"
        ]