export default [
    "Aberration",
    "Animal",
    "Construct",
    "Dragon",
    "Fey",
    "Humanoid",
    "Magical Beast",
    "Monstrous Humanoid",
    "Ooze",
    "Outsider",
    "Plant",
    "Undead",
    "Vermin"
];